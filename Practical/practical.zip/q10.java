package Practical;
class Adder{  
    int add(int a,int b){
        return a+b;
    }  
    int add(int a,int b,int c){
        return a+b+c;
    }  
}  
class q10 {
    public static void main(String[] args){ 
        Adder first = new Adder(); 
        System.out.println(first.add(11,11));  
        System.out.println(first.add(11,11,11));  
        }
}
