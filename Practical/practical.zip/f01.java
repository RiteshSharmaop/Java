package Practical;

public class f01 {
    public static void main(String[] args) {
        System.out.println("Hello Students!");
    }
}
